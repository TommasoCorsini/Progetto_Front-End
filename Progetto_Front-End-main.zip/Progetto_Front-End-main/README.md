# Progetto_Front-End
- Corsini Tommaso
- Cominato Matteo
- Osti Leonardo
